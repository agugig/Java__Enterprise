package ObligatorioEJBS;

import java.util.List;

import ObligatorioEntitys.Actor;

public interface ActorEJBLocal {
	
	public void agregarActor(Actor a);
	public List <Actor> actores();
	public void modificarActor();
	
}
