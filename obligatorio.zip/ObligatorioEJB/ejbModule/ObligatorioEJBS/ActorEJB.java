package ObligatorioEJBS;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import ObligatorioEntitys.Actor;

@Stateless
public class ActorEJB implements ActorEJBLocal {
	
	@PersistenceContext(unitName = "obligatorio")
	private EntityManager em;
	
	@Override
	public void agregarActor(Actor a) {
		em.persist(a);
	}

	@Override
	public List<Actor> actores() {
		Query q = em.createQuery("SELECT a FROM Actor a");
		return q.getResultList();
	}

}
