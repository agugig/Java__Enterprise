package ObligatorioEJBS;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import ObligatorioEntitys.Pelicula;

@Stateless
public class PeliculaEJB implements PeliculaEJBLocal{

	@PersistenceContext(unitName = "obligatorio")
	private EntityManager em;
	
	@Override
	public void agregarPelicula(Pelicula p) {
		em.persist(p);		
	}

	@Override
	public List<Pelicula> peliculas() {
		Query q = em.createQuery("SELECT p FROM Pelicula p");
		return q.getResultList();
	}

	@Override
	public List<Pelicula> buscarPorGenero(String genero) {
		Query q = em.createQuery("SELECT p FROM Pelicula WHERE p.genero = :gen");
		q.setParameter("gen", genero);
		return q.getResultList();
	}

	@Override
	public List<Pelicula> buscarPorProductora(String productora) {
		Query q = em.createQuery("SELECT p FROM Pelicula WHERE p.productora = :produc");
		q.setParameter("produc", productora);
		return q.getResultList();
	}

}
