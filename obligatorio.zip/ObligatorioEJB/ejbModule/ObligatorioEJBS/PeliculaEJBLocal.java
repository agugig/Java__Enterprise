package ObligatorioEJBS;

import java.util.List;

import ObligatorioEntitys.Pelicula;

public interface PeliculaEJBLocal {
	
	public void agregarPelicula(Pelicula p);
	public List <Pelicula> peliculas();
	public List <Pelicula> buscarPorGenero(String genero);
	public List <Pelicula> buscarPorProductora(String productora);
	
}
