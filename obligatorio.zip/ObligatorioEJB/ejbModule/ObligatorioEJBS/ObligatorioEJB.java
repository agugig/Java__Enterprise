package ObligatorioEJBS;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import ObligatorioEntitys.Actor;
import ObligatorioEntitys.Pelicula;

@Stateless
public class ObligatorioEJB implements ObligatorioEJBLocal{
	
	@PersistenceContext(unitName = "obligatorio")
	private EntityManager em;
	
}
