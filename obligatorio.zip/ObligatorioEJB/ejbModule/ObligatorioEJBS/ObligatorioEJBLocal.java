package ObligatorioEJBS;

import java.util.List;

import ObligatorioEntitys.Actor;
import ObligatorioEntitys.Pelicula;

public interface ObligatorioEJBLocal{
	
}
